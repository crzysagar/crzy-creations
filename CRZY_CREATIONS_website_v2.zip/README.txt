CRZY CREATIONS — VERSION 2

New in V2: product detail modal, size selection UI, improved shopping flow, and mobile-ready detail layout.

Still a front-end prototype. Real selling requires a backend/database, real product photos, inventory, customer accounts, payment gateway, shipping, orders, policies and admin dashboard.
