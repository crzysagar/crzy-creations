const products=[
{id:1,n:"Floral Maxi Dress",m:"Dress • Pink",p:1499,c:"#d87397",bg:"#f1d4dc",cat:"dress",tag:"NEW",s:["S","M","L","XL"],d:"A flowy everyday silhouette with a soft, feminine feel."},
{id:2,n:"Black Elegance Dress",m:"Dress • Black",p:1799,c:"#25252a",bg:"#ded9d7",cat:"dress",tag:"BESTSELLER",s:["S","M","L"],d:"A timeless black look for evenings and special moments."},
{id:3,n:"Pastel Co-ord Set",m:"Co-ord • Blue",p:1299,c:"#91adc9",bg:"#dce7ee",cat:"coord",tag:"TRENDING",s:["S","M","L","XL"],d:"A relaxed matching set made for easy styling."},
{id:4,n:"Red Party Gown",m:"Party • Red",p:2499,c:"#a82f43",bg:"#e6c6ca",cat:"party",tag:"LIMITED",s:["S","M","L"],d:"A statement silhouette for celebrations."},
{id:5,n:"White Summer Dress",m:"Dress • White",p:1199,c:"#eee8dc",bg:"#e9e1d7",cat:"dress",tag:"SALE",s:["S","M","L","XL"],d:"Clean, light and effortless from day to evening."},
{id:6,n:"Printed Kurti",m:"Ethnic • Floral",p:899,c:"#cf8185",bg:"#ead8d0",cat:"ethnic",tag:"SALE",s:["M","L","XL","XXL"],d:"A cheerful printed style for everyday comfort."},
{id:7,n:"Lavender Dream Dress",m:"Dress • Lavender",p:1299,c:"#9b85c8",bg:"#e0d8ed",cat:"dress",tag:"NEW",s:["S","M","L"],d:"A playful lavender look with a soft silhouette."},
{id:8,n:"Classic Ethnic Set",m:"Ethnic • Green",p:1599,c:"#6c8067",bg:"#d9e0d5",cat:"ethnic",tag:"NEW",s:["M","L","XL","XXL"],d:"A versatile set for festive days."}];
let cat="all",bag=JSON.parse(localStorage.crzyBag||"[]"),wish=JSON.parse(localStorage.crzyWish||"[]"),size="M";
const ₹=n=>"₹"+n.toLocaleString("en-IN");
function filter(c,b){cat=c;document.querySelectorAll(".filters button").forEach(x=>x.classList.remove("on"));if(b)b.classList.add("on");render();document.getElementById("shop").scrollIntoView({behavior:"smooth"})}
function render(){let q=(search.value||"").toLowerCase(),a=products.filter(x=>(cat=="all"||x.cat==cat)&&(x.n+" "+x.m).toLowerCase().includes(q));none.hidden=!!a.length;productsEl.innerHTML=a.map(x=>`<article class="card"><div class="pic" style="--c:${x.c};--bg:${x.bg}"><span class="tag">${x.tag}</span><button class="heart" onclick="toggleWish(${x.id})">${wish.includes(x.id)?"♥":"♡"}</button><div class="dress"></div></div><div class="info"><h3>${x.n}</h3><p>${x.m}</p><b>${₹(x.p)}</b></div><button class="view" onclick="detail(${x.id})">VIEW PRODUCT</button></article>`).join("")}
function detail(id){let x=products.find(a=>a.id==id);size=x.s[0];document.getElementById("detail").innerHTML=`<div class="detail"><div class="detailart" style="--c:${x.c};--bg:${x.bg}"><div class="dress"></div></div><div><small>${x.m}</small><h2>${x.n}</h2><b>${₹(x.p)}</b><p>${x.d}</p><b>Select size</b><div class="sizes">${x.s.map(s=>`<button class="${s==size?"sel":""}" onclick="pick('${s}',this)">${s}</button>`).join("")}</div><button class="btn" onclick="add(${x.id},size);closeModal()">ADD TO BAG</button></div></div>`;modal.classList.add("open")}
function pick(s,b){size=s;document.querySelectorAll(".sizes button").forEach(x=>x.classList.remove("sel"));b.classList.add("sel")}
function closeModal(){modal.classList.remove("open")}
function toggleWish(id){wish.includes(id)?wish=wish.filter(x=>x!=id):wish.push(id);localStorage.crzyWish=JSON.stringify(wish);render();counts()}
function wishlistView(){if(!wish.length)return alert("Your wishlist is empty. Tap ♡ to save a product.");cat="wish";productsEl.innerHTML=products.filter(x=>wish.includes(x.id)).map(x=>`<article class="card"><div class="pic" style="--c:${x.c};--bg:${x.bg}"><span class="tag">SAVED</span><div class="dress"></div></div><div class="info"><h3>${x.n}</h3><p>${x.m}</p><b>${₹(x.p)}</b></div><button class="view" onclick="detail(${x.id})">VIEW PRODUCT</button></article>`).join("");document.getElementById("shop").scrollIntoView({behavior:"smooth"})}
function add(id,s){let x=bag.find(a=>a.id==id&&a.s==s);x?x.q++:bag.push({id,s,q:1});save();openCart()}
function qty(id,s,d){let x=bag.find(a=>a.id==id&&a.s==s);if(!x)return;x.q+=d;if(x.q<1)bag=bag.filter(a=>a!==x);save()}
function save(){localStorage.crzyBag=JSON.stringify(bag);counts();cart()}
function counts(){bc.textContent=bag.reduce((a,x)=>a+x.q,0);wc.textContent=wish.length}
function cart(){let t=0;cartitems.innerHTML=bag.map(x=>{let p=products.find(a=>a.id==x.id);t+=p.p*x.q;return `<div class="item"><span><b>${p.n}</b><br>Size ${x.s}<br>${₹(p.p*x.q)}</span><span class="qty"><button onclick="qty(${p.id},'${x.s}',-1)">−</button> ${x.q} <button onclick="qty(${p.id},'${x.s}',1)">+</button></span></div>`}).join("")||"<p>Your bag is empty.</p>";total.textContent=₹(t)}
function openCart(){cartPanel();document.getElementById("cart").classList.add("open");shade.classList.add("open")}
function cartPanel(){cart()}
function closeCart(){document.getElementById("cart").classList.remove("open");shade.classList.remove("open")}
function focusSearch(){search.focus();document.getElementById("shop").scrollIntoView({behavior:"smooth"})}
function join(e){e.preventDefault();msg.textContent="You're in! Welcome to the CRZY Fam ❤️";e.target.reset()}
function checkout(){alert("V3 front-end checkout demo. Real payments will be connected after backend setup.")}
const productsEl=document.getElementById("products");render();counts();cart();
